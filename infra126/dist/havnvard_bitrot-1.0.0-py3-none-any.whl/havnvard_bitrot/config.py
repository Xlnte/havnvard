from __future__ import annotations

import json
import os
from dataclasses import dataclass


@dataclass(frozen=True)
class HostConfig:
    name: str
    mode: str
    ssh_target: str | None
    scratch_dir: str | None


@dataclass(frozen=True)
class Settings:
    postgres_url: str
    batch_size: int
    enqueue_page_size: int
    lease_seconds: int
    heartbeat_seconds: int
    hash_timeout_seconds: int
    remote_batch_timeout_seconds: int
    remote_poll_seconds: int
    remote_heartbeat_stale_seconds: int
    auto_accept_mutable_score: int
    stabilization_delay_hours: int
    log_dir: str
    hosts: dict[str, HostConfig]
    tg_command: str | None
    plane_command: str | None
    waitingroom_acquire_command: str | None
    waitingroom_release_command: str | None
    waitingroom_max_wait_seconds: int
    waitingroom_retry_seconds: int
    allow_null_integrations: bool


def _default_hosts() -> dict[str, HostConfig]:
    return {
        "spark-20cf": HostConfig("spark-20cf", "local", None, None),
        "nas-ts453a": HostConfig(
            "nas-ts453a",
            "remote",
            "sparkbkup@nas-ts453a.tail5f354b.ts.net",
            "/share/CACHEDEV1_DATA/.diskaudit_scratch/infra126",
        ),
        "trigkey": HostConfig(
            "trigkey",
            "remote",
            "parker@trigkey.tail5f354b.ts.net",
            "/var/lib/havnvard/infra126",
        ),
    }


def _env_bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1","true","yes","on"}


def load_settings() -> Settings:
    hosts = _default_hosts()
    raw_hosts = os.getenv("INFRA126_HOSTS_JSON")
    if raw_hosts:
        decoded = json.loads(raw_hosts)
        hosts = {
            name: HostConfig(
                name=name,
                mode=value["mode"],
                ssh_target=value.get("ssh_target"),
                scratch_dir=value.get("scratch_dir"),
            )
            for name, value in decoded.items()
        }
    return Settings(
        postgres_url=os.environ["POSTGRES_URL"],
        batch_size=int(os.getenv("INFRA126_BATCH_SIZE", "500")),
        enqueue_page_size=int(os.getenv("INFRA126_ENQUEUE_PAGE_SIZE", "5000")),
        lease_seconds=int(os.getenv("INFRA126_LEASE_SECONDS", "1800")),
        heartbeat_seconds=int(os.getenv("INFRA126_HEARTBEAT_SECONDS", "30")),
        hash_timeout_seconds=int(os.getenv("INFRA126_HASH_TIMEOUT_SECONDS", "1200")),
        remote_batch_timeout_seconds=int(os.getenv("INFRA126_REMOTE_BATCH_TIMEOUT_SECONDS", "1200")),
        remote_poll_seconds=int(os.getenv("INFRA126_REMOTE_POLL_SECONDS", "15")),
        remote_heartbeat_stale_seconds=int(os.getenv("INFRA126_REMOTE_HEARTBEAT_STALE_SECONDS", "300")),
        auto_accept_mutable_score=int(os.getenv("INFRA126_AUTO_ACCEPT_MUTABLE_SCORE", "90")),
        stabilization_delay_hours=int(os.getenv("INFRA126_STABILIZATION_DELAY_HOURS", "24")),
        log_dir=os.getenv("INFRA126_LOG_DIR", "/var/log/havnvard/infra126"),
        hosts=hosts,
        tg_command=os.getenv("INFRA126_TG_COMMAND"),
        plane_command=os.getenv("INFRA126_PLANE_COMMAND"),
        waitingroom_acquire_command=os.getenv("INFRA126_WAITINGROOM_ACQUIRE_COMMAND"),
        waitingroom_release_command=os.getenv("INFRA126_WAITINGROOM_RELEASE_COMMAND"),
        waitingroom_max_wait_seconds=int(os.getenv("INFRA126_WAITINGROOM_MAX_WAIT_SECONDS", "1800")),
        waitingroom_retry_seconds=int(os.getenv("INFRA126_WAITINGROOM_RETRY_SECONDS", "30")),
        allow_null_integrations=_env_bool("INFRA126_ALLOW_NULL_INTEGRATIONS",False),
    )
