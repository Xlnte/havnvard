from __future__ import annotations

import base64
import json
import shlex
import subprocess
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from .types import FileCandidate, HashOutcome, HashResult


@dataclass(frozen=True)
class RemoteJob:
    ssh_target: str
    work_dir: str
    pid: int
    result_file: str
    heartbeat_file: str
    token: str


class RemoteBatchHasher:
    def __init__(
        self,
        helper_script: Path,
        timeout_seconds: int = 1200,
        poll_seconds: int = 15,
        heartbeat_stale_seconds: int = 300,
    ):
        self.helper_script = helper_script
        self.timeout_seconds = timeout_seconds
        self.poll_seconds = poll_seconds
        self.heartbeat_stale_seconds = heartbeat_stale_seconds

    @staticmethod
    def _run(command: list[str], *, timeout: int, check: bool = True) -> subprocess.CompletedProcess[str]:
        return subprocess.run(command, text=True, capture_output=True, timeout=timeout, check=check)

    def launch(self, ssh_target: str, scratch_root: str, run_id: str, candidates: list[FileCandidate]) -> RemoteJob:
        if scratch_root.rstrip("/") == "/tmp" or scratch_root.startswith("/tmp/"):
            raise ValueError("INFRA-126 forbids NAS /tmp; configure persistent diskaudit scratch space")
        safe_run = "".join(ch for ch in run_id if ch.isalnum() or ch in "-_")
        token = f"infra126-{safe_run}-{time.time_ns()}"
        work_dir = f"{scratch_root.rstrip('/')}/{token}"
        with tempfile.TemporaryDirectory(prefix="infra126-manifest-") as temp_dir:
            manifest_path = Path(temp_dir) / "manifest.tsv"
            with manifest_path.open("w", encoding="utf-8") as manifest:
                for item in candidates:
                    encoded = base64.b64encode(item.path.encode("utf-8", errors="surrogateescape")).decode("ascii")
                    manifest.write(f"{item.item_id}\t{encoded}\n")
            remote_manifest = f"{work_dir}/manifest.tsv"
            remote_helper = f"{work_dir}/remote_hash_batch.sh"
            result_file = f"{work_dir}/results.jsonl"
            heartbeat_file = f"{work_dir}/heartbeat"
            pid_file = f"{work_dir}/pid"
            token_file = f"{work_dir}/token"
            self._run(["ssh", ssh_target, f"umask 077; mkdir -p {shlex.quote(work_dir)}; printf %s {shlex.quote(token)} > {shlex.quote(token_file)}"], timeout=60)
            self._run(["scp", "-q", str(manifest_path), f"{ssh_target}:{remote_manifest}"], timeout=120)
            self._run(["scp", "-q", str(self.helper_script), f"{ssh_target}:{remote_helper}"], timeout=120)
            command = (
                f"chmod 700 {shlex.quote(remote_helper)} && "
                f"nohup sh {shlex.quote(remote_helper)} {shlex.quote(remote_manifest)} {shlex.quote(result_file)} "
                f"{shlex.quote(heartbeat_file)} {shlex.quote(token_file)} "
                f"> {shlex.quote(work_dir + '/stdout.log')} 2>&1 & "
                f"echo $! > {shlex.quote(pid_file)}; cat {shlex.quote(pid_file)}"
            )
            started = self._run(["ssh", ssh_target, command], timeout=60)
            pid = int(started.stdout.strip().splitlines()[-1])
            return RemoteJob(ssh_target, work_dir, pid, result_file, heartbeat_file, token)

    def _probe(self, job: RemoteJob) -> tuple[str, int | None]:
        command = (
            f"if test -f {shlex.quote(job.work_dir + '/done')}; then echo done; "
            f"elif kill -0 {job.pid} 2>/dev/null; then echo running; else echo exited; fi; "
            f"cat {shlex.quote(job.heartbeat_file)} 2>/dev/null || true"
        )
        result = self._run(["ssh", job.ssh_target, command], timeout=30, check=False)
        lines = [line.strip() for line in result.stdout.splitlines() if line.strip()]
        state = lines[0] if lines else "exited"
        heartbeat = int(lines[1]) if len(lines) > 1 and lines[1].isdigit() else None
        return state, heartbeat

    def terminate(self, job: RemoteJob) -> None:
        # Kill only the exact PID after validating the per-run token. Never use pkill -f.
        command = (
            f"test \"$(cat {shlex.quote(job.work_dir + '/token')} 2>/dev/null)\" = {shlex.quote(job.token)} "
            f"&& kill {job.pid} 2>/dev/null || true"
        )
        self._run(["ssh", job.ssh_target, command], timeout=30, check=False)

    def wait(self, job: RemoteJob, heartbeat_callback: Callable[[int | None], None] | None = None) -> list[HashResult]:
        deadline = time.monotonic() + self.timeout_seconds
        last_remote_heartbeat: int | None = None
        last_heartbeat_change = time.monotonic()
        while time.monotonic() < deadline:
            state, remote_heartbeat = self._probe(job)
            if heartbeat_callback:
                heartbeat_callback(remote_heartbeat)
            if remote_heartbeat is not None and remote_heartbeat != last_remote_heartbeat:
                last_remote_heartbeat = remote_heartbeat
                last_heartbeat_change = time.monotonic()
            if state == "done":
                break
            if state != "running":
                raise RuntimeError(f"remote hash process exited without completion marker: pid={job.pid}, work_dir={job.work_dir}")
            if time.monotonic() - last_heartbeat_change > self.heartbeat_stale_seconds:
                self.terminate(job)
                raise TimeoutError(
                    f"remote heartbeat stale for >{self.heartbeat_stale_seconds}s; exact PID {job.pid} was terminated"
                )
            time.sleep(self.poll_seconds)
        else:
            self.terminate(job)
            raise TimeoutError(f"remote batch exceeded {self.timeout_seconds}s and exact PID {job.pid} was terminated")

        with tempfile.TemporaryDirectory(prefix="infra126-results-") as temp_dir:
            local_path = Path(temp_dir) / "results.jsonl"
            self._run(["scp", "-q", f"{job.ssh_target}:{job.result_file}", str(local_path)], timeout=120)
            parsed: list[HashResult] = []
            with local_path.open("r", encoding="utf-8") as handle:
                for line in handle:
                    row = json.loads(line)
                    parsed.append(HashResult(
                        item_id=int(row["item_id"]),
                        path=row.get("path", ""),
                        status=HashOutcome(row["status"]),
                        sha256=row.get("sha256"),
                        size=row.get("size"),
                        mtime_ns=row.get("mtime_ns"),
                        inode=row.get("inode"),
                        duration_ms=int(row.get("duration_ms", 0)),
                        error=row.get("error"),
                    ))
            return parsed

    @staticmethod
    def recovery_command(job: RemoteJob) -> str:
        return (
            f"ssh {shlex.quote(job.ssh_target)} "
            f"'test \"$(cat {shlex.quote(job.work_dir + '/token')} 2>/dev/null)\" = {shlex.quote(job.token)} "
            f"&& kill {job.pid}'"
        )
